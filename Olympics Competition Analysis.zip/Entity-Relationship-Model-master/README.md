# Entity Relationship Model
Here I have the ER diagram model with the explaination of scenario and ER diagram images with the SQL commands.
